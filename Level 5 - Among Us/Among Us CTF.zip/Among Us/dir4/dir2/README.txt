Red was not the impostor!

But we can find out who it is...

In the two text files - crew1 and crew2 - there is exactly one word COMMON to both of them. Find that word. That is the second half of the password (and also our impostor!) 

Remember to concatenate the two halves without adding a space in between them.
