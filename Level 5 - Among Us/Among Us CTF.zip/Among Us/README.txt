The key for this level is split into two halves. You have to find both and concatenate them to form the password for the next level. For example if the keys were key_part_one and key_part_two, the password would be key_part_onekey_part_two.

To start off with, look for the text file called AmongUs somewhere in these directories.

All the best!
