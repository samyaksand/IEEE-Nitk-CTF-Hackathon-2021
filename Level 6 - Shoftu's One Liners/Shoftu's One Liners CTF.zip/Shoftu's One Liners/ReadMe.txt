All you have to do is find the Flag!

key format: IEEE{key}
